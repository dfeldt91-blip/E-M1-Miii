MN103 processor module v1.00 for IDA 4.9 Free 

Place mn103.w32 in proc subfolder inside ida installation folder.
Place mn103.cfg in cfg subfolder inside ida installation folder.

If you want auto-comments place ida.int to your ida directory.

Use MN103 CPU for CPU part.