#ifndef INCLUDED_FILEUTILS_HXX
#define INCLUDED_FILEUTILS_HXX

#define NOMINMAX
#include <windows.h>

#include <string>
#include <vector>
#include <stdexcept>
#include <algorithm>

#include "StringUtils.hxx"

class Path
{
public:
	static std::string getcwd()
	{
		static char cwd[MAX_PATH];
		::GetCurrentDirectoryA(MAX_PATH, cwd); // cwd is not terminated with slash

		return cwd;
	}

	static std::string abspath(std::string path)
	{
		return normpath(join(getcwd(), path));
	}

	static std::string normpath(std::string path)
	{
		path = strReplaceAll(path, "/", "\\");
		std::vector<std::string> parts = ::split(path, "\\");
		std::vector<std::string> partsNorm;
		for (int i = 0; i < (int)parts.size(); ++i)
		{
			if (parts[i] == "." && i != 0)
			{
				// "." not at start of path has no meaning, so do not add this part
			}
			else if (parts[i] == ".." && i != 0)
			{
				// ".." not at start of path means go back one folder, so remove last added and do not add this part
				if (partsNorm.size() > 0)
					partsNorm.pop_back();
				else
					partsNorm.push_back(parts[i]); // if not possible to go back one folder, keep ".." in order not to loose data
			}
			else if (parts[i] == "")
			{
				// "" means there will be multiple slashes, do not add this part
			}
			else if (parts[i].find(":") != std::string::npos)
			{
				// containing ":", discard any previous parts
				partsNorm.clear();
				partsNorm.push_back(parts[i]);
			}
			else
			{
				partsNorm.push_back(parts[i]);
			}
		}

		return ::join(partsNorm, "\\");
	}

	// returns 'foo.txt' for '../foo/bar/foo.txt', '' for '/foo/bar/', 'bar' for '/foo/bar', 'foo' for 'foo'
	static std::string basename(std::string path)
	{
		path = normpath(path);
		std::string::size_type p = path.rfind("\\");
		if (p == std::string::npos)
			return path;
		else
			return path.substr(p+1, path.size() - (p+1));
	}

	// returns '../foo/bar' for '../foo/bar/foo.txt', '' for 'foo', 'foo' for 'foo/'
	static std::string dirname(std::string path)
	{
		path = normpath(path);
		std::string::size_type p = path.rfind("\\");
		if (p == std::string::npos)
			return "";
		else
			return path.substr(0, p - 0);
	}

	static std::vector<std::string> split(std::string path)
	{
		std::vector<std::string> result;
		path = normpath(path);
		std::string::size_type p = path.rfind("\\");
		if (p == std::string::npos)
		{
			result.push_back("");
			result.push_back(path);
		}
		else
		{
			result.push_back(path.substr(0, p - 0));
			result.push_back(path.substr(p+1, path.size() - (p+1)));
		}
		return result;
	}

	static std::string join(std::string p1, std::string p2)
	{
		return normpath(p1 + "\\" + p2);
	}

	static std::string join(std::string p1, std::string p2, std::string p3)
	{
		return normpath(p1 + "\\" + p2 + "\\" + p3);
	}

	static std::string join(std::string p1, std::string p2, std::string p3, std::string p4)
	{
		return normpath(p1 + "\\" + p2 + "\\" + p3 + "\\" + p4);
	}

	static std::vector<std::string> splitdrive(std::string path)
	{
		std::vector<std::string> result;
		path = normpath(path);
		std::string::size_type p = path.find(":");
		if (p == std::string::npos)
		{
			result.push_back("");
			result.push_back(path);
		}
		else
		{
			result.push_back(path.substr(0, p - 0));
			result.push_back(path.substr(p+1, path.size() - (p+1)));
		}
		return result;
	}

	static std::vector<std::string> splitext(std::string path)
	{
		std::vector<std::string> result;

		std::string::size_type dot = path.rfind(".");
		if (dot == std::string::npos)
		{
			result.push_back(path);
			result.push_back(""); // no extension
		}
		else
		{
			result.push_back(path.substr(0, dot - 0));
			result.push_back(path.substr(dot, path.size()-dot));
		}

		return result;
	}

	static std::string replaceExtension(std::string path, std::string extensionWithDot)
	{
		std::string::size_type dot = path.rfind(".");
		if (dot == std::string::npos)
		{
			return path + extensionWithDot;
		}
		else
		{
			return path.substr(0, dot - 0) + extensionWithDot;
		}
	}

	static std::string relpath(std::string path, std::string start = ".")
	{
		path = abspath(path);
		start = abspath(start);

		if (splitdrive(path)[0] != splitdrive(start)[0])
			throw std::runtime_error("No relative path possible between different drives.");

		std::vector<std::string> pathSplit = ::split(path, "\\");
		std::vector<std::string> startSplit = ::split(start, "\\");

		std::string relPathStr = "";
		std::vector<std::string>::const_iterator pathTokensIter = pathSplit.begin();
		std::vector<std::string>::const_iterator basePathTokensIter = startSplit.begin();

		while (1)
		{
			// No remaining path tokens, 
			// path is same as base path:
			if (pathTokensIter == pathSplit.end())
			{
				relPathStr = ".";
				break; // end
			}

			// No remaining base path tokens, 
			// path is sub-path of base path:
			if (basePathTokensIter == startSplit.end())
			{
				relPathStr = ".";
				for (pathTokensIter = pathTokensIter; pathTokensIter != pathSplit.end(); ++pathTokensIter)
				{
					relPathStr = join(relPathStr, (*pathTokensIter));
				}
				break; // end
			}

			std::string pathToken = (*pathTokensIter);
			std::string basePathToken = (*basePathTokensIter);

			// Find first token (from beginning) that's different:
			if (pathToken != basePathToken)
			{
				const int numRemainingBaseTokens = (int)std::distance<std::vector<std::string>::const_iterator>(basePathTokensIter, startSplit.end());

				// No remaining base path tokens, 
				// path is a sub-path of base path:
				// XXX: already handled above?
				if (numRemainingBaseTokens == 0)
				{
					relPathStr = ".";
				}
				// Remaining base path tokens, path is 
				// in a 'higher' path than base path, 
				// go back:
				else
				{
					for (int i = 0; i < numRemainingBaseTokens; ++i)
					{
						relPathStr = join(relPathStr, "..");
					}
				}

				// Add remaining path tokens to relative path in order reach path:
				for (std::vector<std::string>::const_iterator i = pathTokensIter; i != pathSplit.end(); ++i)
				{
					relPathStr = join(relPathStr, (*i));
				}

				break; // end
			}

			// Next tokens:
			++pathTokensIter;
			++basePathTokensIter;
		}

		return relPathStr;
	}

	// path can be absolute or relative, creates entire path (not just leaf)
	static bool create(std::string path)
	{
		path = normpath(path);
		std::vector<std::string> pathParts = ::split(path, "\\");

		std::string curPath = "";
		int curPathLevel = 0;
		while (curPathLevel < (int)pathParts.size())
		{
			if (pathParts[curPathLevel].find(":") == std::string::npos && pathParts[curPathLevel] != "." && pathParts[curPathLevel] != "..") // e.g. if not "C:", ".", ".."
				break;
			curPath += pathParts[curPathLevel] + "\\";
			++curPathLevel;
		}

		while (curPathLevel < (int)pathParts.size())
		{
			curPath += pathParts[curPathLevel] + "\\";

			BOOL result = ::CreateDirectoryA(curPath.c_str(), NULL);
			if (result == 0 && ::GetLastError() != ERROR_ALREADY_EXISTS)
				return false; // error

			++curPathLevel;
		}

		return true; // ok
	}
};

#endif
