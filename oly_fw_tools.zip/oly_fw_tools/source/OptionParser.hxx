#ifndef INCLUDED_OPTIONPARSER_HXX
#define INCLUDED_OPTIONPARSER_HXX

#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <cassert>

#include "StringUtils.hxx"

// Simple command line interface parser.
//
// Features/limitations:
//	-	Does not support "arguments" (mandatory, unnamed, ordered), however "options" (named, unordered) 
//		can be set to be both optional and mandatory.
//	-	Does not support short options, only long options, e.g. "--input-file" (not e.g. "-f").
//	-	Does not directly care about type safety, works with strings only.
//	-	Does allow mutually exclusive options, by adding two or more action=STORE_CONST options with
//		different constValue's, but same dest. If in this case more than one option is specified, there 
//		will be a parser error.

enum ActionType
{
	STORE,			// stores string following option flag
	STORE_CONST		// stores supplied constant (any string following option flag will be ignored)
					// note: use constValue = "" to just set a field and use hasOption() to query if it was specified or not
};
// NOTE:
//	STORE_TRUE same as action=STORE_CONST, constValue="true", (and optionally: isMandatory=false, defaultValue="false")
//	STORE_FALSE same as action=STORE_CONST, constValue="false", (and optionally: isMandatory=false, defaultValue="true")

//enum ValueType
//{
//	T_STRING,
//	T_INT,
//	T_FLOAT,
//	T_BOOL,
//	T_NONE
//};

class OptionParser
{
public:
	OptionParser();

	void addOption(std::string flag, std::string dest, bool isMandatory, std::string defaultValue, ActionType action, std::string constValue, std::string help, std::string valueDescr);
	// constValue only used when action=STORE_CONST
	// defaultValue only used when isMandatory=false
	
	void parseArgs(int nArgs, char *args[]);
	// arguments like those passed to int main(int, char*[])

	void printUsage(std::string prog);

	bool hasOption(std::string dest) const;
	std::string getOptionAsString(std::string dest) const;
	int getOptionAsInt(std::string dest) const;
	float getOptionAsFloat(std::string dest) const;
	bool getOptionAsBool(std::string dest) const;

private:
	struct Destination
	{
		std::string name;
		bool isMandatory;
		std::string defaultValue;

		std::vector<std::string> flagsTargeting;
		std::string getTargetingFlagsAsPrettyString() const
		{
			std::string s = join(flagsTargeting, "|");
			if (flagsTargeting.size() > 1)
				s = "[" + s + "]";
			return s;
		}
	};

	struct ParseSpec
	{
		std::string flag;
		std::string dest;
		ActionType action;
//		ValueType valueType;
		std::string constValue;
		std::string help;
	};

	struct Result
	{
		std::string value;
		std::string setByFlag;
	};

	std::vector<Destination> destinations_;
	// list of destinations, for checking if all mandatory ones were set, and using default value for unset optional ones
	
	std::vector<ParseSpec> toParse_;
	// list of items to parse
	
	std::map<std::string, Result> map_;
	// {dest name, value} map

private:
	std::string appendSpacer(std::string str, int size);
	std::string wrapTextExceptFirstLine(std::string str, int indent, int wrapAt);
};

// ---------------------------------------------------------------------------------------

inline OptionParser::OptionParser()
{
}

inline void OptionParser::addOption(std::string flag, std::string dest, bool isMandatory, std::string defaultValue, ActionType action, std::string constValue, std::string help, std::string valueDescr)
{
	// Required:
	//	-	flag must start with "--"
	//	-	flag may not contain "="
	//	-	each flag must be uniquely named
	//
	// Not required:
	//	-	multiple options with same dest should be consistent, but if they are 
	//		not simply the first specified will be used
	//	-	if isMandatory=true, defaultValue is not used, but if it is set to something 
	//		in this case, no error will be generated
	//	-	if isMandatory=false, defaultValue will be used, but in case it is not specified 
	//		no error will be generated; however if after parsing this value is accessed, an 
	//		error will occur
	//	-	when action!=STORE_CONST, constValue will not be used, but if it is set to something 
	//		in this case, no error will be generated
	//	-	action=STORE_CONST with constValue="" is valid, but after parsing only hasOption() can 
	//		be used

	if (!startsWith(flag, "--"))
		throw std::runtime_error("Invalid flag specified!"); // not really a run-time error, more programming error

	if (flag.find("=") != std::string::npos)
		throw std::runtime_error("Invalid flag specified!"); // not really a run-time error, more programming error

	for (int itemIdx = 0; itemIdx < (int)toParse_.size(); ++itemIdx)
	{
		if (flag == toParse_[itemIdx].flag)
			throw std::runtime_error("Duplicate flag specified!"); // not really a run-time error, more programming error
	}

	// Add to destinations list:
	std::vector<Destination>::iterator found = destinations_.end();
	for (std::vector<Destination>::iterator destIter = destinations_.begin(); destIter != destinations_.end(); ++destIter)
	{
		if ((*destIter).name == dest)
		{
			found = destIter;
			break;
		}
	}

	if (found == destinations_.end())
	{
		Destination newDest;
		newDest.name = dest;
		newDest.isMandatory = isMandatory;
		newDest.defaultValue = defaultValue;
		
		std::string flagTargeting = flag;
		if (action == STORE)
			if (valueDescr == "")
				flagTargeting += "=VALUE";
			else
				flagTargeting += "=" + valueDescr;

		newDest.flagsTargeting.push_back(flagTargeting);

		destinations_.push_back(newDest);
	}
	else
	{
		// NOTE:
		// We do not check for consistency between different options with the same dest, 
		// we simply use the first option's properties and ignore the following ones.

		std::string flagTargeting = flag;
		if (action == STORE)
			if (valueDescr == "")
				flagTargeting += "=VALUE";
			else
				flagTargeting += "=" + valueDescr;

		(*found).flagsTargeting.push_back(flagTargeting);
	}

	// Add item to parse:
	ParseSpec spec;
	spec.flag = flag;
	spec.dest = dest;
	spec.action = action;
	spec.help = help;
	spec.constValue = constValue;

	toParse_.push_back(spec);
}

inline void OptionParser::parseArgs(int nArgs, char *args[])
{
	// Clear results from previous parseArgs() runs:
	map_.clear();

	// Create arguments string:
	std::string argString = "";
	const int skip = 1; // avoid first argument (executable name)
	for (int argIdx = skip; argIdx < nArgs; ++argIdx)
	{
		if (argIdx != skip)
			argString += " ";
		argString += args[argIdx];
	} 

	// Check for special arguments:
	if (argString == "" || argString.find("-?") != std::string::npos || argString.find("--?") != std::string::npos || argString.find("-help") != std::string::npos || argString.find("--help") != std::string::npos )
	{
		throw std::runtime_error(""); // no error, just print usage message
	}

	// Parse items:
	std::vector<std::string> errorList;
	for (std::vector<ParseSpec>::const_iterator mapIter = toParse_.begin(); mapIter != toParse_.end(); ++mapIter)
	{
		std::string flag = (*mapIter).flag;
		std::string dest = (*mapIter).dest;
		ActionType action = (*mapIter).action;
		std::string constVal = (*mapIter).constValue;

		// find flag:
		std::string::size_type b = argString.find(flag); // find first occurrence

		// check if e.g. "--in" doesn't match on "--inspect":
		while (b != std::string::npos)
		{
			std::string::size_type fe = b+flag.size();
			if (fe == argString.size()) // end of flag is end of command line argument
				break; // ok
			else if (argString[fe] == ' ') // end of flag is space
				break; // ok
			else
				b = argString.find(flag, b+flag.size()); // not ok, try search again from further position
		}

		if (b == std::string::npos)
			continue;

		// find option end:
		std::string::size_type e;
		e = argString.find(" --", b+flag.size()); // next flag
		if (e == std::string::npos)
			e = argString.size(); // end of string

		// extract value:
		std::string option = argString.substr(b, e-b);

		std::string val = "";
		std::string::size_type bVal = option.find_first_of("= "); // allow "--flag=bla bla" and "--flag bla bla"
		if (bVal != std::string::npos)
		{
			bVal += 1; // skip '=' or ' '

			std::string::size_type eVal = option.size(); // until end of option, not until first whitespace

			val = option.substr(bVal, eVal-bVal);

			// strip surrounding quotes:
			val = lstrip(val, "\"");
			val = rstrip(val, "\"");
		}

		// fill map:
		std::map<std::string, Result>::const_iterator found = map_.find(dest);
		if (found == map_.end())
		{
			Result r;
			if (action == STORE)
				r.value = val;
			else if (action == STORE_CONST)
				r.value = constVal;

			r.setByFlag = flag;
			
			map_.insert(std::map<std::string, Result>::value_type(dest, r));
		}
		else
		{
			std::string toSetVal;
			if (action == STORE)
				toSetVal = val;
			else if (action == STORE_CONST)
				toSetVal = constVal;

			if (toSetVal != (*found).second.value) // two flags target same destination, but with different values; so they are effectively mutually exclusive
				errorList.push_back("Flags " + flag + " and " + (*found).second.setByFlag + " are mutually exclusive.");
		}
	}

	// Check if all destinations were filled:
	for (std::vector<Destination>::const_iterator destIter = destinations_.begin(); destIter != destinations_.end(); ++destIter)
	{
		std::string dest = (*destIter).name;

		std::map<std::string, Result>::const_iterator found = map_.find(dest);

		if (found == map_.end())
		{
			if ((*destIter).isMandatory)
			{
				errorList.push_back("Mandatory flag " + (*destIter).getTargetingFlagsAsPrettyString() + " was not specified.");
			}
			else
			{
				Result r;
				r.value = (*destIter).defaultValue;
				r.setByFlag = "default"; // not used
				map_.insert(std::map<std::string, Result>::value_type(dest, r));
			}
		}
	}

	// Handle errors:
	std::string errorString = "";
	for (int i = 0; i < (int)errorList.size(); ++i)
	{
		errorString += errorList[i];
		if (i != (int)errorList.size()-1)
			errorString += "\n";
	}

	if (errorList.size() > 0)
		throw std::runtime_error(errorString);
}

inline void OptionParser::printUsage(std::string prog)
{
	// strip path:
	prog = strReplaceAll(prog, "/", "\\");
	std::string::size_type sep = prog.rfind("\\");
	if (sep != std::string::npos)
		prog = prog.substr(sep+1, prog.size() - (sep+1));

	// options:
	std::vector<std::string> options;
	for (int destIdx = 0; destIdx < (int)destinations_.size(); ++destIdx)
	{
		std::string option = destinations_[destIdx].getTargetingFlagsAsPrettyString();
		if (!destinations_[destIdx].isMandatory)
			option = "(" + option + ")";

		options.push_back(option);
	}

	// detailed help:
	std::vector<std::string> flags;
	std::vector<std::string> details;
	int maxFlagWidth = 0;
	for (int itemIdx = 0; itemIdx < (int)toParse_.size(); ++itemIdx)
	{
		flags.push_back(toParse_[itemIdx].flag);
		details.push_back(toParse_[itemIdx].help);

		if ((int)toParse_[itemIdx].flag.size() > maxFlagWidth)
			maxFlagWidth = toParse_[itemIdx].flag.size();
	}

	std::string help = "";
	for (int itemIdx = 0; itemIdx < (int)toParse_.size(); ++itemIdx)
	{
		std::string line = flags[itemIdx];
		line = appendSpacer(line, maxFlagWidth + 3);
		line += details[itemIdx];
		line = wrapTextExceptFirstLine(line, maxFlagWidth + 3, std::max(80, maxFlagWidth + 3 + 20));
		help += line + "\n";
	}


	std::string exeLine = prog + " " + join(options, " ");
	exeLine = wrapTextExceptFirstLine(exeLine, (int)prog.size() + 1, std::max(80, (int)prog.size() + 1 + 20));

	std::cout << exeLine << std::endl;
	std::cout << std::endl;
	std::cout << help; // help already ends in new line
}

inline bool OptionParser::hasOption(std::string dest) const
{
	return (map_.find(dest) != map_.end());
}

inline std::string OptionParser::getOptionAsString(std::string dest) const
{
	std::map<std::string, Result>::const_iterator iter = map_.find(dest);
	if (iter == map_.end())
		throw std::runtime_error("Invalid flag specified.");
	return (*iter).second.value;
}

inline int OptionParser::getOptionAsInt(std::string dest) const
{
	return convStr2Int(getOptionAsString(dest));
}

inline float OptionParser::getOptionAsFloat(std::string dest) const
{
	return convStr2Float(getOptionAsString(dest));
}

inline bool OptionParser::getOptionAsBool(std::string dest) const
{
	return convStr2Bool(getOptionAsString(dest));
}

inline std::string OptionParser::appendSpacer(std::string str, int size)
{
	assert(size > (int)str.size());
	return str + std::string(size - str.size(), ' ');
}

inline std::string OptionParser::wrapTextExceptFirstLine(std::string str, int indent, int wrapAt)
{
	assert(indent < wrapAt);

	std::string result = "";

	int lineCount = 0;

	while (1)
	{
		// str fits, stop:
		if (indent + (int)str.size() < wrapAt)
		{
			if (lineCount > 0)
				result += std::string(indent, ' ');
			result += str;
			break;
		}

		// break part of str, keep rest:
		std::string::size_type pos = str.rfind(" ", wrapAt - indent);
		if (pos == std::string::npos)
		{
			// can't break line (no preceding white space):
			if (lineCount > 0)
				result += std::string(indent, ' ');
			result += str;
			break;
		}

		if (lineCount > 0)
			result += std::string(indent, ' ');
		result += str.substr(0, pos + 1) + "\n";
		str = str.substr(pos + 1, str.size() - (pos + 1)); // remaining string
		lineCount += 1;
	}

	return result;
}

#endif
