#ifndef INCLUDED_STDINT_HXX
#define INCLUDED_STDINT_HXX

#ifdef _MSC_VER // MSVC
	typedef unsigned char byte;

	typedef char int8_t;
	typedef char int_least8_t;
	typedef char int_fast8_t;
	typedef unsigned char uint8_t;
	typedef unsigned char uint_least8_t;
	typedef unsigned char uint_fast8_t;

	typedef short int16_t;
	typedef short int_least16_t;
	typedef short int_fast16_t;
	typedef unsigned short uint16_t;
	typedef unsigned short uint_least16_t;
	typedef unsigned short uint_fast16_t;

	typedef long int32_t;
	typedef long int_least32_t;
	typedef long int_fast32_t;
	typedef unsigned long uint32_t;
	typedef unsigned long uint_least32_t;
	typedef unsigned long uint_fast32_t;

	typedef __int64 int64_t;
	typedef __int64 int_least64_t;
	typedef __int64 int_fast64_t;
	typedef unsigned __int64 uint64_t;
	typedef unsigned __int64 uint_least64_t;
	typedef unsigned __int64 uint_fast64_t;

	typedef int64_t intmax_t;
	typedef uint64_t uintmax_t;
#else
	#error StdInt.hxx not implemented for this platform.
#endif

#endif


