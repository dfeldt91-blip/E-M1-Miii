#ifndef INCLUDED_BYTEUTILS_HXX
#define INCLUDED_BYTEUTILS_HXX

#include <cstdio>
#include <string>
#include <stdexcept>

#include "StdInt.hxx"
#include "StringUtils.hxx"

// checks if two byte arrays are identical, like memcmp() but returning bool
inline bool memeql(const byte *p1, const byte *p2, size_t n)
{
	for (size_t i = 0; i < n; ++i)
	{
		if (p1[i] != p2[i])
			return false;
	}
	return true;
}

// checks if all bytes in an array have the same given value 'val'
inline bool memchk(const byte *p, byte val, size_t n)
{
	for (size_t i = 0; i < n; ++i)
	{
		if (p[i] != val)
			return false;
	}
	return true;
}

// -------------------------------------------------------------------------------------------------

inline std::string convHexSeq2Str(byte *src, size_t len)
{
	std::string dst = "";
	for (size_t i = 0; i < len; ++i)
	{
		dst += format("%02x", int(src[i]));
	}
	return dst;
	// (should never fail)
}

inline std::string convHexInt162Str(uint16_t src)
{
	return format("%04x", src);
	// (should never fail)
}

inline std::string convHexInt322Str(uint32_t src)
{
	return format("%08x", src);
	// (should never fail)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline void convStr2HexSeq(byte *dst, size_t dstLen, std::string s)
{
	char tmp[3];
	tmp[2] = '\0';

	const char *src = s.c_str();
	const size_t srcLen = s.size();
	
	size_t dstIdx = 0;
	for (size_t srcIdx = 0; srcIdx < srcLen; srcIdx += 2)
	{
		tmp[0] = src[srcIdx+0];
		tmp[1] = src[srcIdx+1];
		
		int n;
		if (sscanf(tmp, "%x", &n) != 1)
			throw std::runtime_error("Hex string conversion failed.");
		
		if (dstIdx >= dstLen)
			throw std::runtime_error("Hex string size exceeds target data size.");

		dst[dstIdx] = (byte)n;
		++dstIdx;
	}
}

inline uint32_t convStr2HexInt(std::string s)
{
	uint32_t dst;
	if (sscanf(s.c_str(), "%x", &dst) != 1)
		throw std::runtime_error("Hex string conversion failed.");
	return dst;
}

// -------------------------------------------------------------------------------------------------

inline uint16_t swapEndian16(uint16_t x)
{
	x = (x>>8) | 
		(x<<8);
	return x;
}

inline uint32_t swapEndian32(uint32_t x)
{
	x =	(x>>24) | 
		((x<<8) & 0x00FF0000) |
		((x>>8) & 0x0000FF00) |
		(x<<24);
	return x;
}

// -------------------------------------------------------------------------------------------------

inline bool isAsciiPrintable(byte c)
{
	return ((c >= 32 && c <= 126) || c == '\t' || c == 0x0a || c == 0x0d);
}

inline bool isAsciiLetter(byte c)
{
	return ((c >= 65 && c <= 90) || (c >= 97 && c <= 122));
}

// -------------------------------------------------------------------------------------------------

#include <set>

// very specialized code to check whether all bytes in a block of data have been used
class UsedByteRangeCheck
{
public:
	struct Range
	{
		uint32_t b;
		uint32_t e;
	};

	UsedByteRangeCheck(uint32_t len)
	{
		Range r;
		r.b = 0;
		r.e = len;
		unusedRanges_.insert(r);
	}

	void markAsUsed(uint32_t b, uint32_t e)
	{
		if (b >= e)
			return;

		std::set<Range, RangeLessThan> unusedRanges2;
		std::set<Range, RangeLessThan>::iterator it;
		for (it = unusedRanges_.begin(); it != unusedRanges_.end(); ++it)
		{
			Range r = (*it);
			// case 1:
			//r          ------------
			//   b------------e
			//>               -------
			if (b <= r.b && e >= r.b && e < r.e)
			{
				r.b = e;
				r.e = r.e;

				unusedRanges2.insert(r);
			}

			// case 2:
			//r          ------------
			//                    b-----e
			//>          ----------
			else if (b > r.b && b < r.e && e >= r.e)
			{
				r.b = r.b;
				r.e = b;

				unusedRanges2.insert(r);
			}

			// case 3:
			//r          ------------
			//               b----e
			//>          -----    ---
			else if (b > r.b && e < r.e)
			{
				Range r1;
				r1.b = r.b;
				r1.e = b;

				Range r2;
				r2.b = e;
				r2.e = r.e;

				unusedRanges2.insert(r1);
				unusedRanges2.insert(r2);
			}

			// case 4:
			//r          ------------
			//      b--------------------e
			//>                           
			else if (b <= r.b && e >= r.e)
			{
				// (do nothing)
			}

			// case 5:
			//r          ------------
			//                           b--e
			//>          ------------
			else
			{
				unusedRanges2.insert(r);
			}
		}

		unusedRanges_ = unusedRanges2;
	}

	int size() const
	{
		return (int)std::distance(unusedRanges_.begin(), unusedRanges_.end());
	}

	Range operator[](int idx)
	{
		std::set<Range, RangeLessThan>::iterator it;
		it = unusedRanges_.begin();
		std::advance(it, idx);
		return (*it);
	}

private:
	struct RangeLessThan
	{
		bool operator()(const Range &lhs, const Range &rhs) const
		{
			return (lhs.b < rhs.b);
		}
	};

	std::set<Range, RangeLessThan> unusedRanges_;
};

#endif