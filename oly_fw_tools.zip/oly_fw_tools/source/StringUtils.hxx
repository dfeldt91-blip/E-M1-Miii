#ifndef INCLUDED_STRINGUTILS_HXX
#define INCLUDED_STRINGUTILS_HXX

#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <iterator>
#include <stdexcept>

// replace all occurrences of a in s with b
inline std::string strReplaceAll(const std::string &s, const std::string &a, const std::string &b)
{
	std::string result = s;
	std::string::size_type pos = 0;

	while (1)
	{
		pos = result.find(a, pos);

		if (pos == std::string::npos)
			break; // done

		result.replace(pos, a.size(), b);

		pos += a.size();
	}

	return result;
}

// -------------------------------------------------------------------------------------------------

inline std::vector<std::string> slicelist(const std::vector<std::string> &list, int b, int e)
{
	std::vector<std::string> result;
	for (int i = b; i < e; ++i)
	{
		result.push_back(list[i]);
	}
	return result;
}

// Split string 'str' on all occurrences of substring 'sep'.
//
// E.g.:
// split("aaa::bbb::ccc", "::") = ["aaa", "bbb", "ccc"]
// split("a; b; c;", ";") = ["a", " b", " c", ""]
// split("abc", "#") = ["abc"]
//
// Same as Python's str.split(sep).
//
// Note that there's an overload of split() with no 'sep' argument which splits on any white space 
// character (and skips all white space).
inline std::vector<std::string> split(std::string str, std::string sep)
{
	std::vector<std::string> v;
	if (sep.size() == 0)
	{
//		throw std::runtime_error("empty separator"); // Python's split() behavior
		v.push_back(str); // return [str]
	}
	else
	{
		std::string::size_type bpos = 0;
		while (1)
		{
			std::string::size_type epos = str.find(sep, bpos);
			if (epos == std::string::npos)
			{
				v.push_back(str.substr(bpos, str.size()-bpos));
				break;
			}
			else
			{
				v.push_back(str.substr(bpos, epos-bpos));
				bpos = epos + sep.size();
			}
		}
	}

	return v;
}

// Split string 'str' on any whitespace character (and strip all whitespace).
//
// E.g.:
// split("    aaa  bbb     ") = ["aaa", "bbb"]
//
// Same as Python's str.split() (with no argument).
inline std::vector<std::string> split(std::string str)
{
	std::istringstream iss(str);
	std::vector<std::string> v;
	std::copy(std::istream_iterator<std::string>(iss), std::istream_iterator<std::string>(), std::back_inserter<std::vector<std::string> >(v));
	return v;
}

inline std::string join(const std::vector<std::string> &list, const std::string &sep)
{
	std::string result = "";
	for (int i = 0; i < (int)list.size(); ++i)
	{
		result += list[i];
		if (i != list.size()-1)
			result += sep;
	}
	return result;
}

// -------------------------------------------------------------------------------------------------

// strip any leading/trailing character in what (if not specified, any white space)
inline std::string strip(const std::string &s, const std::string &what = " \t\n\r")
{
	std::string::size_type b = s.find_first_not_of(what);
	if (b == std::string::npos)
		return ""; // input string was all white space (or empty)
	std::string::size_type last = s.find_last_not_of(what); // if b != npos, then last is also != npos
	std::string::size_type e = last+1;
	return s.substr(b, e-b);
}

// strip any leading character in what (if not specified, any white space)
inline std::string lstrip(const std::string &s, const std::string &what = " \t\n\r")
{
	std::string::size_type b = s.find_first_not_of(what);
	if (b == std::string::npos)
		return ""; // input string was all white space (or empty)
	std::string::size_type e = s.size();
	return s.substr(b, e-b);
}

// strip any trailing character in what (if not specified, any white space)
inline std::string rstrip(const std::string &s, const std::string &what = " \t\n\r")
{
	std::string::size_type last = s.find_last_not_of(what);
	if (last == std::string::npos)
		return ""; // input string was all white space (or empty)
	std::string::size_type b = 0;
	std::string::size_type e = last+1;
	return s.substr(b, e-b);
}

// stripts whole of sub, not any char in sub
inline std::string lstripSub(const std::string &s, const std::string &sub)
{
	std::string::size_type p = s.find(sub);
	if (p == std::string::npos)
		return s;

	std::string::size_type b = p + sub.size();
	return s.substr(b, s.size() - b);
}

// stripts whole of sub, not any char in sub
inline std::string rstripSub(const std::string &s, const std::string &sub)
{
	std::string::size_type p = s.rfind(sub);
	if (p == std::string::npos)
		return s;

	return s.substr(0, p - 0);
}

// -------------------------------------------------------------------------------------------------

inline bool startsWith(const std::string &s, const std::string &what)
{
	return (s.find(what) == 0);
}

inline bool endsWith(const std::string &s, const std::string &what)
{
	if (what.size() > s.size())
		return false;
	return (s.rfind(what) == s.size() - what.size());
}

// -------------------------------------------------------------------------------------------------

// looks for subOut = "aa bb" in s = "xyz [aa bb] xyz" with bTag = "[" and eTag = "]"
// returns end of search (use as offset argument for subsequent calls), or npos if failed
inline std::string::size_type getSubWithinTags(const std::string &s, const std::string &bTag, const std::string &eTag, std::string &subOut, std::string::size_type offset = 0)
{
	std::string::size_type bFind = std::string::npos; // begin before bTag
	std::string::size_type eFind = std::string::npos; // end after eTag

	bFind = s.find(bTag, offset);
	if (bFind != std::string::npos)
	{
		eFind = s.find(eTag, bFind+bTag.size());
		if (eFind != std::string::npos)
		{
			eFind += eTag.size();

			std::string::size_type b = bFind + bTag.size();
			std::string::size_type e = eFind - eTag.size();
			subOut = s.substr(b, e-b);
		}
	}

	return eFind;
}

// -------------------------------------------------------------------------------------------------

inline int convStr2Int(const std::string &s)
{
	int result;
	std::stringstream ss;
	ss << s;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert string \"" + s + "\" to integer.");
	return result;
}

inline std::string convInt2Str(int v)
{
	std::string result;
	std::stringstream ss;
	ss << v;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert integer to string.");
	return result;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline int convHexStr2Int(const std::string &s)
{
	unsigned int result;
	std::stringstream ss;
	ss << std::hex << s;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert hex string \"" + s + "\" to integer.");
	return result;
}

inline std::string convInt2HexStr(int v, bool use0xPrefix = true)
{
	std::string result;
	std::stringstream ss;
	ss << std::hex << v;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert integer to hex string.");
	if (use0xPrefix)
		result = "0x" + result;
	return result;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline float convStr2Float(const std::string &s)
{
	float result;
	std::stringstream ss;
	ss << s;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert string \"" + s + "\" to float.");
	return result;
}

inline std::string convFloat2Str(float v)
{
	std::string result;
	std::stringstream ss;
	ss << v;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert float to string.");
	return result;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline double convStr2Double(const std::string &s)
{
	double result;
	std::stringstream ss;
	ss << s;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert string \"" + s + "\" to double.");
	return result;
}

inline std::string convDouble2Str(double v)
{
	std::string result;
	std::stringstream ss;
	ss << v;
	ss >> result;
	if (!ss)
		throw std::runtime_error("Could not convert double to string.");
	return result;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

inline bool convStr2Bool(const std::string &s)
{
	bool result;
	if (s == "true")
		return true;
	else if (s == "false")
		return false;
	else
		throw std::runtime_error("Could not convert string \"" + s + "\" to bool.");
	return result;
}

inline const char *convBool2Str(bool b)
{
	if (b)
		return "true";
	else
		return "false";
}

// -------------------------------------------------------------------------------------------------

#include <cstdarg>

inline std::string format_arg_list(const char *fmt, va_list args)
{
	if (!fmt)
		return "";

	int result = -1;
	int length = 256; // initial size to allocate
	char *buffer = 0;
	while (result == -1)
	{
		if (buffer)
			delete[] buffer;
		buffer = new char[length + 1]; // allocate
		memset(buffer, 0, length + 1);
		result = _vsnprintf(buffer, length, fmt, args); // this is for msvc, other gcc vsnprintf() is similar but return value is different (so condition above should also change)
		length *= 2; // double space in case doesn't fit
	}
	std::string s(buffer); // allocate, copy
	delete[] buffer;
	return s;
}

// like sprintf, but without having to manually allocate/deallocate memory
// not so efficient however
inline std::string format(const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	std::string s = format_arg_list(fmt, args);
	va_end(args);
	return s;
}

#endif