#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <string>
#include <map>

#include "tinyxml/tinyxml.h"

#include "StdInt.hxx"
#include "ByteUtils.hxx"
#include "StringUtils.hxx"
#include "FileUtils.hxx"
#include "OptionParser.hxx"

#include "OlympusFwScramble.hxx"
#include "OlympusFwChecksum.hxx"
#include "OlympusFwConstants.hxx"
#include "OlympusFwResources.hxx"
#include "EstimateLoadAddress.hxx"

void unpackFirmware(std::string fnInput, std::string fnOutput, bool testMode = false);
void packFirmware(std::string fnInput, std::string fnOutput);
void extractFirmware(std::string fnInput, std::string fnOutput);
void analyzeFirmware(std::string fnInput, std::string fnOutput);
void unpackSFirmware(std::string fnInput, std::string fnOutput);

enum Mode
{
	UNPACK,
	PACK,
	EXTRACT,
	ANALYZE,
	UNPACK_S
};

std::string gFnModelNameTableEMA = "oly_models_body.xml";
std::string gFnModelNameTableL = "oly_models_lens.xml";

int main(int nArgs, char *args[])
{
	printf("Olympus E-series Firmware Tool\n");
	printf("Version 1.02 -- USE AT OWN RISK!\n");
	printf("\n");

	// Handle command line arguments:
	OptionParser opt;
	opt.addOption("--unpack", "mode", true, "", STORE_CONST, convInt2Str(UNPACK), "Unpack and descramble (original) firmware.", "");
	opt.addOption("--pack", "mode", true, "", STORE_CONST, convInt2Str(PACK), "Pack and scramble (modified) firmware.", "");
	opt.addOption("--extract-resources", "mode", true, "", STORE_CONST, convInt2Str(EXTRACT), "Extract media resources (images, sounds, text, etc.) from unpacked firmware. Can't fully extract all resources!", "");
	opt.addOption("--analyze", "mode", true, "", STORE_CONST, convInt2Str(ANALYZE), "Analyze unpacked firmware MN103 machine code in order to guess loading address.", "");
	opt.addOption("--unpack-s", "mode", true, "", STORE_CONST, convInt2Str(UNPACK_S), "Unpack Smmmvvvv.BIN firmware (from service/repair card firmware update packages). Can't re-pack!", "");
	opt.addOption("--in", "input", true, "", STORE, "", "Input firmware binary .bin (unpacking, unpacking-s, unpacking-test), firmware description .xml (packing, extracting) or unpacked code block binary .bin (analyzing).", "PATH");
	opt.addOption("--out", "output", true, "", STORE, "", "Output firmware description .xml file (unpacking), firmware binary .bin file (packing), target folder (extracting, analyzing, unpacking-s), or empty (test unpacking w/o output).", "PATH");

	Mode mode;
	std::string fnInput;
	std::string fnOutput;

	try
	{
		opt.parseArgs(nArgs, args);
		mode = Mode(opt.getOptionAsInt("mode"));
		fnInput = opt.getOptionAsString("input");
		fnOutput = opt.getOptionAsString("output");
	}
	catch (std::exception &e)
	{
		opt.printUsage(args[0]);
		
		if (std::string(e.what()) != "")
		{
			printf("\n");
			printf("Error(s):\n");
			printf("%s\n", e.what());
		}

		return 1;
	}

	// Do the work:
	try
	{
		if (mode == UNPACK)
		{
			if (fnOutput == "")
				unpackFirmware(fnInput, fnOutput, true);
			else
				unpackFirmware(fnInput, fnOutput, false);
		}
		else if (mode == PACK)
		{
			packFirmware(fnInput, fnOutput);
		}
		else if (mode == EXTRACT)
		{
			extractFirmware(fnInput, fnOutput);
		}
		else if (mode == ANALYZE)
		{
			analyzeFirmware(fnInput, fnOutput);
		}
		else if (mode == UNPACK_S)
		{
			unpackSFirmware(fnInput, fnOutput);
		}
	}
	catch (std::exception &e)
	{
		printf("\n");
		printf("Error(s):\n");
		printf("%s\n", e.what());

		// parsable output for unpack-test mode
		if (mode == UNPACK && fnOutput == "")
		{
			printf("\n");
			printf("VALIDATE ERROR");
		}

		return 1;
	}

//	printf("Done!\n");

	return 0;
}

// -------------------------------------------------------------------------------------------------

void unpackFirmware(std::string fnInput, std::string fnOutput, bool testMode)
{
	TiXmlDocument doc;
	std::string errorMsg;
	FILE *fhInput = NULL;
	TiXmlDeclaration *decl = NULL;
	TiXmlElement *olyFwElem = NULL;
	byte *body = NULL;
	byte *unscrambledBlock = NULL;

	// load model name tables:
	std::map<int, std::string> modelNameTableEMA = readModelNameTableFromXml(gFnModelNameTableEMA);
	std::map<int, std::string> modelNameTableL = readModelNameTableFromXml(gFnModelNameTableL);
	// may throw (but no need to goto error, because first in function)
	
	// make sure output folder exists:
	std::string path = Path::replaceExtension(fnOutput, ".dissected");
	if (!testMode)
	{
		if (!Path::create(path))
		{
			errorMsg = "Can't create output folder.";
			goto error;
		}
	}

	// open file:
	fhInput = fopen(fnInput.c_str(), "rb");
	if (!fhInput)
	{
		errorMsg = "Can't open input file.";
		goto error;
	}

	// Create XML DOM:
	decl = new TiXmlDeclaration("1.0", "", "");
	olyFwElem = new TiXmlElement("olympus_fw");

	size_t blockCount = 0;
	byte modelSigFirstBlk[2]; // for checking consistency between blocks
	modelSigFirstBlk[0] = 0xFF; // assume 0xFF won't be used for valid model signatures
	modelSigFirstBlk[1] = 0xFF;

	byte typeSigFirstBlk[2]; // for parsable output
	typeSigFirstBlk[0] = 0xFF; // assume invalid
	typeSigFirstBlk[1] = 0xFF;
	uint16_t versionFirstBlk = 0xFFFF; // invalid

	// while not eof:
	while (!feof(fhInput))
	{
		size_t p;
		size_t n;

		// read block head:
		// -------------------------------------------------------------------------------
		BlockHeadTail head;
		p = ftell(fhInput);
		n = fread((void *)&head, 1, sizeof(BlockHeadTail), fhInput);
		if (n == 0)
		{
			break; // normal EOF
		}
		if (n != sizeof(BlockHeadTail))
		{
			errorMsg = 
				"Reached OEF while reading block head!\n" +
				format("At position %d expected %d bytes, could read only %d bytes", p, sizeof(BlockHeadTail), n);
			goto error;
		}

		// check/print fields:
		// -------------------------------------------------------------------------------
		printf("Block %02d:\n", blockCount);

		// block type signature (always valid):
		char typeSigStr[3];
		typeSigStr[0] = head.typeSig[0];
		typeSigStr[1] = head.typeSig[1];
		typeSigStr[2] = '\0';
		printf("Block type signature:\t0x%02X%02X (\"%s\")\t%s\n", head.typeSig[0], head.typeSig[1], typeSigStr, getBlockDescr(head.typeSig).c_str());

		// model signature (check if consistent between all blocks):
		printf("Model signature:\t0x%02X%02X\t\t%s\n", head.modelSig[0], head.modelSig[1], getModelDescr(head.typeSig, head.modelSig, modelNameTableEMA, modelNameTableL).c_str());

		if (modelSigFirstBlk[0] == 0xFF && modelSigFirstBlk[1] == 0xFF)
		{
			modelSigFirstBlk[0] = head.modelSig[0];
			modelSigFirstBlk[1] = head.modelSig[1];
		}
		else
		{
			if (modelSigFirstBlk[0] != head.modelSig[0] || modelSigFirstBlk[1] != head.modelSig[1])
			{
				printf("Warning: Model signatures not consistent for all blocks in file!\n");
				// (this happens in real firmwares, not an error)
			}
		}

		if (typeSigFirstBlk[0] == 0xFF && typeSigFirstBlk[1] == 0xFF)
		{
			typeSigFirstBlk[0] = head.typeSig[0];
			typeSigFirstBlk[1] = head.typeSig[1];
		}

		if (versionFirstBlk == 0xFFFF)
			versionFirstBlk = head.version;

		// zero-padding (check if really zero):
		const bool isZp1Unknown = !memchk(head.zeroPadding1, 0x00, 4);
		if (isZp1Unknown)
		{
			printf("Warning: Zero-padding/unknown field was not zero!\n");
			printf("         Data was 0x%02X 0x%02X 0x%02X 0x%02X\n", head.zeroPadding1[0], head.zeroPadding1[1], head.zeroPadding1[2], head.zeroPadding1[3]);
		}

		// loading address (always valid):
		printf("Loading address:\t0x%08X\n", head.loadingAddress);

		// body length (check if within remaining length of file):
		printf("Size (body):\t\t%d bytes (0x%08X)\n", head.len, head.len);
		long curPos = ftell(fhInput); // p+n
		fseek(fhInput, 0, SEEK_END);
		size_t fileLen = ftell(fhInput);
		fseek(fhInput, curPos, SEEK_SET);
		size_t remainingLen = fileLen - curPos;
		if (head.len > remainingLen)
		{
			errorMsg = "Block length exceeds remaining file length. Input file format probably not supported.";
			goto error;
		}

		// version (always valid):
		printf("Version:\t\t0x%04X\n", head.version);

		// zero-padding (check if really zero):
		const bool isZp2Unknown = !memchk(head.zeroPadding2, 0x00, 2);
		if (isZp2Unknown)
		{
			printf("Warning: Zero-padding/unknown field was not zero!\n");
			printf("         Data was 0x%02X 0x%02X\n", head.zeroPadding2[0], head.zeroPadding2[1]);
		}

		// flags (always valid):
		printf("Flags:\t\t\t0x%04X\t\t%s\n", head.flags, getFlagsDescr(head.flags));

		// zero-padding (check if really zero):
		const bool isZp3Unknown = !memchk(head.zeroPadding3, 0x00, 6);
		if (isZp3Unknown)
		{
			printf("Warning: Zero-padding/unknown field was not zero!\n");
			printf("         Data was 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X\n", head.zeroPadding3[0], head.zeroPadding3[1], head.zeroPadding3[2], head.zeroPadding3[3], head.zeroPadding3[4], head.zeroPadding3[5]);
		}

		// checksum (must be zero for head):
		if (head.checksum != 0)
		{
			errorMsg = 
				"Checksum of head was not zero!\n" +
				format("Data was 0x%08X\n", head.checksum) +
				"It will NOT be possible to correctly re-assemble this firmware!";
			goto error;
		}

		// -------------------------------------------------------------------------------
		// read block body:
		const size_t m = head.len;
		body = new byte[m];
		p = ftell(fhInput);
		n = fread((void *)body, 1, m, fhInput);

		if (n != m)
		{
			errorMsg = 
				"Reached OEF while reading block body!\n" +
				format("At position %d expected %d bytes, could read only %d bytes", p, m, n);
			goto error;
		}

		// -------------------------------------------------------------------------------
		// read block tail:
		BlockHeadTail tail;
		p = ftell(fhInput);
		n = fread((void *)&tail, 1, sizeof(BlockHeadTail), fhInput);
		if (n != sizeof(BlockHeadTail))
		{
			errorMsg = 
				"Reached OEF while reading block tail!\n" +
				format("At position %d expected %d bytes, could read only %d bytes", p, sizeof(BlockHeadTail), n);
			goto error;
		}

		// -------------------------------------------------------------------------------
		// check consistency head/tail:
		byte *p1 = (byte *)&head;
		byte *p2 = (byte *)&tail;
		if (!memeql(p1, p2, sizeof(BlockHeadTail)-4)) // skip last 4 checksum bytes!
		{
			errorMsg = "Block head and tail not consistent!";
			goto error;
		}

		// -------------------------------------------------------------------------------
		// unscramble block body:
		const size_t k = sizeof(BlockHeadTail) + m + sizeof(BlockHeadTail);
		unscrambledBlock = new byte[k];

		bool isScrambled = (head.flags != 0x0000); // XXX: perhaps should be: (flags & 0x0100) != 0

		if (isScrambled)
		{
			memcpy(&unscrambledBlock[0], &head, sizeof(BlockHeadTail)); // copy head
			descrambleData(&unscrambledBlock[sizeof(BlockHeadTail)], body, m); // unscramble body
			memcpy(&unscrambledBlock[sizeof(BlockHeadTail) + m], &tail, sizeof(BlockHeadTail)); // copy tail
		}
		else
		{
			// not scrambled, just copy to continuous chunk of memory:
			memcpy(&unscrambledBlock[0], &head, sizeof(BlockHeadTail));
			memcpy(&unscrambledBlock[sizeof(BlockHeadTail)], body, m);
			memcpy(&unscrambledBlock[sizeof(BlockHeadTail)+m], &tail, sizeof(BlockHeadTail));
		}

		// -------------------------------------------------------------------------------
		// check checksum:
		printf("Checksum:\t\t0x%08X\n", tail.checksum);

		uint32_t checksum;
		checksum = computeChecksum(unscrambledBlock, k-4); // skip last 4 bytes of tail (checksum itself)

		if (checksum != tail.checksum)
		{
			errorMsg = 
				"Checksum of unscrambled data did not match!\n" +
				format("Expected checksum: 0x%08X\n", tail.checksum) +
				format("Compute checksum: 0x%08X\n", checksum);
			goto error;
		}

		// write unscrambled body:
		std::string fnBodyUnscr;
		fnBodyUnscr = format("%s\\%02d.%s.bin", path.c_str(), blockCount, getBlockTypeFn(head.typeSig, head.flags).c_str());

		if (!testMode)
		{
			FILE *fhBodyUnscr = fopen(fnBodyUnscr.c_str(), "wb");
			if (!fhBodyUnscr)
			{
				errorMsg = "Failed to open unscrambled block body file for writing!";
				goto error;
			}
			else
			{
				fwrite(&unscrambledBlock[sizeof(BlockHeadTail)], 1, m, fhBodyUnscr);
				fclose(fhBodyUnscr);
			}
		}

		// Add block to XML:
		TiXmlElement *blockElem = new TiXmlElement("block");
		blockElem->SetAttribute("sig", convHexSeq2Str(head.typeSig, 2));
		blockElem->SetAttribute("model", convHexSeq2Str(head.modelSig, 2));
		if (isZp1Unknown)
			blockElem->SetAttribute("unknown1", convHexSeq2Str(head.zeroPadding1, 4));
		blockElem->SetAttribute("addr", convHexInt322Str(head.loadingAddress));
		blockElem->SetAttribute("len", convHexInt322Str(head.len));
		blockElem->SetAttribute("version", convHexInt162Str(head.version));
		if (isZp2Unknown)
			blockElem->SetAttribute("unknown2", convHexSeq2Str(head.zeroPadding2, 2));
		blockElem->SetAttribute("flags", convHexInt162Str(head.flags));
		if (isZp3Unknown)
			blockElem->SetAttribute("unknown3", convHexSeq2Str(head.zeroPadding3, 6));
		blockElem->SetAttribute("file", Path::relpath(fnBodyUnscr, Path::dirname(fnOutput)));
		olyFwElem->LinkEndChild(blockElem);

		// -------------------------------------------------------------------------------
		// clean up:
		delete[] body;
		body = NULL;
		delete[] unscrambledBlock;
		unscrambledBlock = NULL;

		// -------------------------------------------------------------------------------
		// next block:
		++blockCount;

		printf("\n");
	}

	// Save XML DOM:
	doc.LinkEndChild(decl);
	doc.LinkEndChild(olyFwElem);
	if (!testMode)
		doc.SaveFile(fnOutput.c_str());

	printf("Processed %d bytes.\n", ftell(fhInput));

	// close file:
	fclose(fhInput);

	printf("\n");

	// generate parsable output string
	char blkTypeLetter[2];
	blkTypeLetter[0] = typeSigFirstBlk[1];
	blkTypeLetter[1] = '\0';
	printf("VALIDATE OK %s %02X%02X %04X", blkTypeLetter, modelSigFirstBlk[0], modelSigFirstBlk[1], versionFirstBlk);
	
	return;

error:
	if (fhInput != NULL)
		fclose(fhInput);
	delete decl;
	delete olyFwElem;
	delete[] body;
	delete[] unscrambledBlock;
	throw std::runtime_error(errorMsg);
}

// -------------------------------------------------------------------------------------------------

// XML helpers

bool hasXmlAttrib(const TiXmlElement *element, const char *attribName)
{
	const char *v = element->Attribute(attribName);
	return (v != NULL);
}

void getHexSequenceFromXmlAttrib(byte *dst, int dstLen, const TiXmlElement *element, const char *attribName)
{
	std::string s;
	if (element->QueryStringAttribute(attribName, &s) != TIXML_SUCCESS)
		throw std::runtime_error("Failed reading attribute from XML.");
	convStr2HexSeq(dst, dstLen, s);
}

uint32_t getHexIntFromXmlAttrib(const TiXmlElement *element, const char *attribName)
{
	std::string s;
	if (element->QueryStringAttribute(attribName, &s) != TIXML_SUCCESS)
		throw std::runtime_error("Failed reading attribute from XML.");
	return convStr2HexInt(s);
}

std::string getStringFromXmlAttrib(const TiXmlElement *element, const char *attribName)
{
	std::string s;
	if (element->QueryStringAttribute(attribName, &s) != TIXML_SUCCESS)
		throw std::runtime_error("Failed reading attribute from XML.");
	return s;
}

// -------------------------------------------------------------------------------------------------

void packFirmware(std::string fnInput, std::string fnOutput)
{
	FILE *fhOutput = fopen(fnOutput.c_str(), "wb");
	if (!fhOutput)
	{
		throw std::runtime_error("Couldn't open output file.");
	}

	TiXmlDocument doc(fnInput.c_str());
	bool docOk = doc.LoadFile();
	if (!docOk)
	{
		throw std::runtime_error("Couldn't open input file.");
	}

	const TiXmlNode *root = doc.RootElement();
	if (!root)
	{
		throw std::runtime_error("Input XML file is invalid (no root element).");
	}

	const TiXmlElement *olyFw = root->ToElement();
	if (!olyFw || olyFw->ValueStr() != "olympus_fw")
	{
		throw std::runtime_error("Input XML file is invalid (no olympus_fw element).");
	}

	for (const TiXmlElement *block = olyFw->FirstChildElement(); block != NULL; block = block->NextSiblingElement())
	{
		if (block->ValueStr() != "block")
		{
			printf("Warning: Found unexpected XML element, ignoring.\n");
			continue;
		}

		std::string file = getStringFromXmlAttrib(block, "file");
		file = Path::join(Path::dirname(fnInput), file);

		printf("%s\n", file.c_str());

		// Open block file:
		FILE *fhBlk = fopen(file.c_str(), "rb");

		if (!fhBlk)
		{
			throw std::runtime_error("Couldn't open unscrambled block body file.");
		}

		// Get block length:
		fseek(fhBlk, 0, SEEK_END);
		size_t blkBodyLen = ftell(fhBlk);
		fseek(fhBlk, 0, SEEK_SET);

		if (blkBodyLen == 0)
		{
			printf("Warning: Zero size block.\n");
		}

		int descriptionLen = getHexIntFromXmlAttrib(block, "len");
		if (blkBodyLen != descriptionLen)
		{
			printf("Warning: Block size in XML description not same as file size.\n");
		}

		size_t blkFullLen = sizeof(BlockHeadTail) + blkBodyLen + sizeof(BlockHeadTail);

		// Allocate memory:
		byte *blkFullUnscrambled = new byte[blkFullLen];
		byte *blkBodyUnscrambled = &blkFullUnscrambled[sizeof(BlockHeadTail)];
		BlockHeadTail *blkHeadUnscrambled = (BlockHeadTail *)&blkFullUnscrambled[0];
		BlockHeadTail *blkTailUnscrambled = (BlockHeadTail *)&blkFullUnscrambled[sizeof(BlockHeadTail) + blkBodyLen];

		byte *blkFullScrambled = new byte[blkFullLen];
		byte *blkBodyScrambled = &blkFullScrambled[sizeof(BlockHeadTail)];
		BlockHeadTail *blkHeadScrambled = (BlockHeadTail *)&blkFullScrambled[0];
		BlockHeadTail *blkTailScrambled = (BlockHeadTail *)&blkFullScrambled[sizeof(BlockHeadTail) + blkBodyLen];

		// Fill header:
		getHexSequenceFromXmlAttrib(blkHeadUnscrambled->typeSig, 2, block, "sig");
		getHexSequenceFromXmlAttrib(blkHeadUnscrambled->modelSig, 2, block, "model");
		memset(blkHeadUnscrambled->zeroPadding1, 0, 4);
		if (hasXmlAttrib(block, "unknown1"))
			getHexSequenceFromXmlAttrib(blkHeadUnscrambled->zeroPadding1, 4, block, "unknown1");
		blkHeadUnscrambled->loadingAddress = getHexIntFromXmlAttrib(block, "addr");
		blkHeadUnscrambled->len = blkBodyLen;
		blkHeadUnscrambled->version = (uint16_t)getHexIntFromXmlAttrib(block, "version");
		memset(blkHeadUnscrambled->zeroPadding2, 0, 2);
		if (hasXmlAttrib(block, "unknown2"))
			getHexSequenceFromXmlAttrib(blkHeadUnscrambled->zeroPadding2, 2, block, "unknown2");
		blkHeadUnscrambled->flags = (uint16_t)getHexIntFromXmlAttrib(block, "flags");
		memset(blkHeadUnscrambled->zeroPadding3, 0, 6);
		if (hasXmlAttrib(block, "unknown3"))
			getHexSequenceFromXmlAttrib(blkHeadUnscrambled->zeroPadding2, 6, block, "unknown3");
		blkHeadUnscrambled->checksum = 0;

		// Fill tail:
		memcpy(blkTailUnscrambled, blkHeadUnscrambled, sizeof(BlockHeadTail));

		// Read unscrambled body:
		fread(blkBodyUnscrambled, blkBodyLen, 1, fhBlk);

		// Compute checksum:
		blkTailUnscrambled->checksum = computeChecksum(blkFullUnscrambled, blkFullLen);

		// Scramble body:
		bool isScrambled = (blkHeadUnscrambled->flags != 0x0000); // XXX: perhaps should be: (flags & 0x0100) != 0

		if (isScrambled)
		{
			scrambleData(blkBodyScrambled, blkBodyUnscrambled, blkBodyLen);
		}
		else
		{
			memcpy(blkBodyScrambled, blkBodyUnscrambled, blkBodyLen);
		}

		// Copy head/tail:
		memcpy(blkHeadScrambled, blkHeadUnscrambled, sizeof(BlockHeadTail));
		memcpy(blkTailScrambled, blkTailUnscrambled, sizeof(BlockHeadTail));

		// Write to output:
		fwrite(blkFullScrambled, blkFullLen, 1, fhOutput);

		// Free memory:
		delete[] blkFullUnscrambled;
		delete[] blkFullScrambled;

		// Close block file:
		fclose(fhBlk);
	}

	fclose(fhOutput);
}

// -------------------------------------------------------------------------------------------------

void extractFirmware(std::string fnInput, std::string fnOutput)
{
	TiXmlDocument doc(fnInput.c_str());
	bool docOk = doc.LoadFile();
	if (!docOk)
	{
		throw std::runtime_error("Couldn't open input file.");
	}

	if (!Path::create(fnOutput))
	{
		throw std::runtime_error("Couldn't create output folder.");
	}

	const TiXmlNode *root = doc.RootElement();
	if (!root)
	{
		throw std::runtime_error("Input XML file is invalid (no root element).");
	}

	const TiXmlElement *olyFw = root->ToElement();
	if (!olyFw || olyFw->ValueStr() != "olympus_fw")
	{
		throw std::runtime_error("Input XML file is invalid (no melody element).");
	}

	int blkCount = 0;
	for (const TiXmlElement *block = olyFw->FirstChildElement(); block != NULL; block = block->NextSiblingElement())
	{
		if (block->ValueStr() != "block")
		{
			printf("Warning: Found unexpected XML element, ignoring.\n");
			continue;
		}

		std::string file = getStringFromXmlAttrib(block, "file");
		file = Path::join(Path::dirname(fnInput), file);

		printf("%s\n", file.c_str());

		// Open block file:
		FILE *fhBlk = fopen(file.c_str(), "rb");

		if (!fhBlk)
		{
			throw std::runtime_error("Couldn't open unscrambled block body file.");
		}

		// Get block length:
		fseek(fhBlk, 0, SEEK_END);
		size_t blkBodyLen = ftell(fhBlk);
		fseek(fhBlk, 0, SEEK_SET);

		byte *blkBodyUnscrambled = new byte[blkBodyLen];

		uint32_t addr = getHexIntFromXmlAttrib(block, "addr");
		uint16_t flags = (uint16_t)getHexIntFromXmlAttrib(block, "flags");

		// Read unscrambled body:
		fread(blkBodyUnscrambled, blkBodyLen, 1, fhBlk);

		// Parse content:
		try
		{
			parseBlockBody(blkBodyUnscrambled, blkBodyLen, flags, addr, fnOutput, blkCount);
		}
		catch (...)
		{
			 delete[] blkBodyUnscrambled;
			 fclose(fhBlk);
			 throw; // re-throw
		}

		// Clean up:
		delete[] blkBodyUnscrambled;

		fclose(fhBlk);

		++blkCount;
	}
}

// -------------------------------------------------------------------------------------------------

void analyzeFirmware(std::string fnInput, std::string fnOutput)
{
	if (!Path::create(fnOutput))
	{
		throw std::runtime_error("Couldn't create output folder.");
	}

	std::string fhOutBase = Path::splitext(Path::basename(fnInput))[0];

	// Open block file:
	FILE *fhBlk = fopen(fnInput.c_str(), "rb");

	if (!fhBlk)
	{
		throw std::runtime_error("Couldn't open unscrambled block body file.");
	}

	// Get block length:
	fseek(fhBlk, 0, SEEK_END);
	size_t blkBodyLen = ftell(fhBlk);
	fseek(fhBlk, 0, SEEK_SET);

	byte *blkBodyUnscrambled = new byte[blkBodyLen];

	// Read unscrambled body:
	fread(blkBodyUnscrambled, blkBodyLen, 1, fhBlk);

	// Analyze content:
	uint32_t loadingAddress = estimateLoadAddress(blkBodyUnscrambled, blkBodyLen, 2000, fnOutput, fhOutBase);
	verifyLoadAddress(blkBodyUnscrambled, blkBodyLen, loadingAddress, fnOutput, fhOutBase);

	// Clean up:
	delete[] blkBodyUnscrambled;

	fclose(fhBlk);
}

// -------------------------------------------------------------------------------------------------

void unpackSFirmware(std::string fnInput, std::string fhOutput)
{
	// load model name tables:
	std::map<int, std::string> modelNameTableEMA = readModelNameTableFromXml(gFnModelNameTableEMA);
	std::map<int, std::string> modelNameTableL = readModelNameTableFromXml(gFnModelNameTableL);
	// (may throw)

	// make sure output folder exists:
	std::string path = fhOutput;
	if (!Path::create(path))
	{
		throw std::runtime_error("Can't create output folder.");
	}

	// open file:
	FILE *fhInput = fopen(fnInput.c_str(), "rb");
	if (!fhInput)
	{
		throw std::runtime_error("Can't open input file.");
	}

	// get file size:
	fseek(fhInput, 0, SEEK_END);
	uint32_t flen = ftell(fhInput);
	fseek(fhInput, 0, SEEK_SET);

	// read all file:
	byte *data = new byte[flen];
	fread(data, flen, 1, fhInput);
	fclose(fhInput);

	// check file length:
	if (flen < sizeof(BlockTailSFile))
	{
		delete[] data;
		throw std::runtime_error("File length too small to be valid S file block.");
	}
	
	BlockTailSFile *tail = (BlockTailSFile *)&data[flen-sizeof(BlockTailSFile)];

	// check tail id:
	if (strncmp((const char *)tail->id, "BOOT", 4) != 0)
	{
		delete[] data;
		throw std::runtime_error("Tail of S file should contain \"BOOT\" id.");
	}

	int blockCount = 0;
	printf("Block %02d:\n", blockCount);

	// check tail type sig:
	// (always valid)
	char typeSigStr[3];
	typeSigStr[0] = tail->typeSig[0];
	typeSigStr[1] = tail->typeSig[1];
	typeSigStr[2] = '\0';
	printf("Block type signature:\t0x%02X%02X (\"%s\")\t%s\n", tail->typeSig[0], tail->typeSig[1], typeSigStr, getBlockDescr(tail->typeSig).c_str());

	// check tail model sig:
	// (always valid)
	printf("Model signature:\t0x%02X%02X\t\t%s\n", tail->modelSig[0], tail->modelSig[1], getModelDescr(tail->typeSig, tail->modelSig, modelNameTableEMA, modelNameTableL).c_str());

	// check tail zero padding 1:
	if (!memchk(tail->zeroPadding1, 0x00, 12))
	{
		delete[] data;
		throw std::runtime_error("Zero-padding contained non-zero data.");
	}

	// check tail checksum:
	printf("Checksum:\t\t0x%08X\n", tail->checksum);
	const uint32_t checksumFile = tail->checksum;
	tail->checksum = 0; // do not include checksum itself in checksum computation
	const uint32_t checksum = computeChecksum(data, flen);
	if (checksum != checksumFile)
	{
		delete[] data;
		throw std::runtime_error("Invalid checksum.");
	}

	// check tail loading address:
	// (always valid)
	printf("Loading address:\t0x%08X\n", tail->loadingAddress);

	// check tail version:
	// (always valid)
	printf("Version:\t\t0x%04X\n", tail->version);
	
	// check tail zero padding 2:
	if (!memchk(tail->zeroPadding2, 0x00, 2))
	{
		delete[] data;
		throw std::runtime_error("Zero-padding contained non-zero data.");
	}

	// save unpacked file (remove tail):
	std::string fnBodyUnscr;
	fnBodyUnscr = format("%s\\%02d.%s.bin", path.c_str(), 0, "s-code");

	FILE *fhBodyUnscr = fopen(fnBodyUnscr.c_str(), "wb");
	if (!fhBodyUnscr)
	{
		delete[] data;
		throw std::runtime_error("Failed to open output file for writing.");
	}
	else
	{
		fwrite(data, 1, flen-sizeof(BlockTailSFile), fhBodyUnscr);
		fclose(fhBodyUnscr);
	}

	printf("Processed %d bytes.\n", flen);

	delete[] data;
}