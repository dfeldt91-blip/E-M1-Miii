#ifndef INCLUDED_OLYMPUSFWRESOURCES_HXX
#define INCLUDED_OLYMPUSFWRESOURCES_HXX

#include <cstdio>
#include <string>
#include <stdexcept>

#include "StdInt.hxx"
#include "FileUtils.hxx"
#include "ByteUtils.hxx"
#include "OlympusFwBlockHeadTail.hxx"

// ---------------------------------------------------------------------------------------
// CODE BLOCK
// ---------------------------------------------------------------------------------------

inline void parseCodeBlock(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	// (nothing to parse; code block does not contain any structure, just block of machine code/data)
}

// ---------------------------------------------------------------------------------------
// LANG BLOCK
// ---------------------------------------------------------------------------------------

#pragma pack(push) // remember struct alignment
#pragma pack(1) // set struct alignment to 1 byte
struct LangHeader
{
	uint32_t addr;
	uint32_t len;
	uint32_t unk1;
	uint32_t unk2;
};
#pragma pack(pop) // restore struct alignment

#pragma pack(push) // remember struct alignment
#pragma pack(1) // set struct alignment to 1 byte
struct LangSubHeader
{
	uint32_t langId;
	byte langStr[4]; // 3 letter id, null-terminated
	// .. more? ..
};
#pragma pack(pop) // restore struct alignment


inline const char *estimateLangType(const byte *data, size_t len)
{
	if (len >= 8)
	{
		LangSubHeader *header = (LangSubHeader *)data;
		if (isAsciiLetter(header->langStr[0]) && isAsciiLetter(header->langStr[1]) && isAsciiLetter(header->langStr[2]) && header->langStr[3] == '\0')
			return (const char *)header->langStr;
	}

	return "UNKN";
}

// E-PL1:
// 00 = ? 16 bytes
// 01 = ? 1.89 mb
// 02 = JPN
// 03 = ENU
// 04-35 = other lang

inline void parseLangBlock(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	// Blocks have a fixed length sub-block with headers only, some padding, data, some more padding:
	uint32_t bDataSection;
	if (flags == FLAGS_LANG)
		bDataSection = 0x000003E0;
	else
		throw std::runtime_error("Unknown flags for image block, can't parse.");

	if (len < bDataSection)
		throw std::runtime_error("Block length too small to have valid header sub-block.");

	// For debugging, mark which bytes have been used from the block:
	UsedByteRangeCheck usedRangeCheck(len);

	// Check headers:
	size_t headerCount = 0;
	const LangHeader *header = (const LangHeader *)unscrambledBody;
	for (; ; ++header, ++headerCount)
	{
		if (headerCount*sizeof(LangHeader) >= bDataSection)
			break;

		// Mark header bytes as used:
		const uint32_t bHeader = headerCount*sizeof(LangHeader);
		const uint32_t eHeader = bHeader + sizeof(LangHeader);
		usedRangeCheck.markAsUsed(bHeader, eHeader);

		// Check for empty header (each header probably corresponds to a
		// resource index, but not all of the indexes point to actual data):
		if (header->len == 0x00000000 && header->addr == 0x00000000)
			continue;

		if (header->len == 0xFFFFFFFF && header->addr == 0xFFFFFFFF)
			continue;

		// Check if len and addr are valid:
		const uint32_t bBody = addr + sizeof(BlockHeadTail);
		ptrdiff_t bRes = header->addr - bBody;
		ptrdiff_t eRes = bRes + header->len;

		if (bRes < 0 || bRes >= ptrdiff_t(len) ||
			eRes < 0 || eRes > ptrdiff_t(len))
		{
			throw std::runtime_error("Resource boundaries exceed data.");
		}

		// Save resource to file:
		std::string fnOut = Path::join(path, format("%02d.lang%02d-%s.%s", blkCount, headerCount, estimateLangType(&unscrambledBody[bRes], eRes-bRes), "bin"));
		FILE *fh = fopen(fnOut.c_str(), "wb");
		if (!fh)
		{
			throw std::runtime_error("Couldn't open output file for writing.");
		}
		else
		{
			fwrite(&unscrambledBody[bRes], 1, eRes-bRes, fh);
			fclose(fh);
		}

		// Mark resource bytes as used:
		usedRangeCheck.markAsUsed(bRes, eRes);
	}

	// Check if unused bytes are data:
	for (int i = 0; i < usedRangeCheck.size(); ++i)
	{
		bool unusedRangeContainsData = false;
		for (size_t k = usedRangeCheck[i].b; k < usedRangeCheck[i].e; ++k)
		{
			if (unscrambledBody[k] != 0xFF && unscrambledBody[k] != 0x00)
			{
				unusedRangeContainsData = true;
				break;
			}
		}

		if (unusedRangeContainsData)
			printf("Warning: Unused data range 0x%08X-0x%08X contains data other than 0x00 and 0xFF.\n", usedRangeCheck[i].b, usedRangeCheck[i].e);
	}
}

// ---------------------------------------------------------------------------------------
// IMG BLOCK
// ---------------------------------------------------------------------------------------

#pragma pack(push) // remember struct alignment
#pragma pack(1) // set struct alignment to 1 byte
struct ImgHeader
{
	uint32_t len;
	uint32_t addr;
};
#pragma pack(pop) // restore struct alignment

// estimates file extension of image data
// these are fairly crude checks that might not be conclusive in all cases
inline const char *estimateImgTypeExt(const byte *data, size_t len)
{
	// Test for JPEG:
	if (len >= 4)
	{
		// FFD8 is SOI start of image
		// FFD9 is EOI end of image
		if (data[0] == 0xFF && data[1] == 0xD8 && data[len-2] == 0xFF && data[len-1] == 0xD9)
			return "jpg";
	}

	// Test for ICO:
	if (len >= 22) // ICO header is 22 bytes, or more (depending on the number of icons in the file)
	{
		uint16_t reserved = *(uint16_t *)&data[0]; // must be zero
		uint16_t type = *(uint16_t *)&data[2]; // 1 for icon
		uint16_t count = *(uint16_t *)&data[4]; // number of icons
		// (follows <count> headers with width/height etc. and the 16x16, 24x24 and/or 32x32 bitmap data,
		// with 1 bit transparency mask; newer Windows Vista icons may contain an additional 
		// 256x256 RGBA bitmap in PNG format)

		if (
			reserved == 0 && 
			type == 1 && 
			count >= 1
			// XXX: could check some more because e.g. 0x0000 0x0100 0x0400 may occur in 
			// various file formats
			)
		{
			return "ico";
		}
	}

	// Test for BMP:
	if (len >= 6) // test only first 6 bytes of header
	{
		uint16_t size = *(uint16_t *)&data[2];
		if (data[0] == 'B' && data[1] == 'M' && size == len)
			return "bmp";
	}

	// Unknown:
	return "unknown.bin";
}

inline void parseImgBlock(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	// Blocks have a fixed length sub-block with headers only, some padding, data, some more padding:
	uint32_t bDataSection;
	if (flags == FLAGS_IMGS1)
		bDataSection = 0x00000BE0;
	else if (flags == FLAGS_IMGS2)
		bDataSection = 0x000003E0;
	else
		throw std::runtime_error("Unknown flags for image block, can't parse.");

	if (len < bDataSection)
		throw std::runtime_error("Block length too small to have valid header sub-block.");

	// For debugging, mark which bytes have been used from the block:
	UsedByteRangeCheck usedRangeCheck(len);

	// Check headers:
	size_t headerCount = 0;
	const ImgHeader *header = (const ImgHeader *)unscrambledBody;
	for (; ; ++header, ++headerCount)
	{
		if (headerCount*sizeof(ImgHeader) >= bDataSection)
			break;

		// Mark header bytes as used:
		const uint32_t bHeader = headerCount*sizeof(ImgHeader);
		const uint32_t eHeader = bHeader + sizeof(ImgHeader);
		usedRangeCheck.markAsUsed(bHeader, eHeader);

		// Check for empty header (each header probably corresponds to a
		// resource index, but not all of the indexes point to actual data):
		if (header->len == 0x00000000 && header->addr == 0x00000000)
			continue;

		if (header->len == 0xFFFFFFFF && header->addr == 0xFFFFFFFF)
			continue;

		// Check if len and addr are valid:
		const uint32_t bBody = addr + sizeof(BlockHeadTail);
		ptrdiff_t bRes = header->addr - bBody;
		ptrdiff_t eRes = bRes + header->len;

		if (bRes < 0 || bRes >= ptrdiff_t(len) ||
			eRes < 0 || eRes > ptrdiff_t(len))
		{
			throw std::runtime_error("Resource boundaries exceed data.");
		}

		// Save resource to file:
		std::string fnOut = Path::join(path, format("%02d.img%02d.%s", blkCount, headerCount, estimateImgTypeExt(&unscrambledBody[bRes], eRes-bRes)));
		FILE *fh = fopen(fnOut.c_str(), "wb");
		if (!fh)
		{
			throw std::runtime_error("Couldn't open output file for writing.");
		}
		else
		{
			fwrite(&unscrambledBody[bRes], 1, eRes-bRes, fh);
			fclose(fh);
		}

		// Mark resource bytes as used:
		usedRangeCheck.markAsUsed(bRes, eRes);
	}

	// Check if unused bytes are data:
	for (int i = 0; i < usedRangeCheck.size(); ++i)
	{
		bool unusedRangeContainsData = false;
		for (size_t k = usedRangeCheck[i].b; k < usedRangeCheck[i].e; ++k)
		{
			if (unscrambledBody[k] != 0xFF && unscrambledBody[k] != 0x00)
			{
				unusedRangeContainsData = true;
				break;
			}
		}
		
		if (unusedRangeContainsData)
			printf("Warning: Unused data range 0x%08X-0x%08X contains data other than 0x00 and 0xFF.\n", usedRangeCheck[i].b, usedRangeCheck[i].e);
	}
}

// ---------------------------------------------------------------------------------------
// SND BLOCK
// ---------------------------------------------------------------------------------------

#pragma pack(push) // remember struct alignment
#pragma pack(1) // set struct alignment to 1 byte
struct SndHeader
{
	uint32_t len;
	uint32_t addr;
	uint32_t flags;
};
#pragma pack(pop) // restore struct alignment

// estimates file extension of sound data
// these are fairly crude checks that might not be conclusive in all cases
inline const char *estimateSndTypeExt(const byte *data, size_t len)
{
	// Test for WAVE:
	if (len >= 12)
	{
		if (strncmp((const char *)&data[0], "RIFF", 4) == 0 && strncmp((const char *)&data[8], "WAVE", 4) == 0)
			return "wav";
	}

	// Unknown:
	return "unknown.bin";
}

inline void parseSndBlock(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	// Blocks have a fixed length sub-block with headers only, some padding, data, some more padding:
	uint32_t bDataSection;
	if (flags == FLAGS_SNDS)
		bDataSection = 0x000003E0;
	else
		throw std::runtime_error("Unknown flags for image block, can't parse.");

	if (len < bDataSection)
		throw std::runtime_error("Block length too small to have valid header sub-block.");

	// For debugging, mark which bytes have been used from the block:
	UsedByteRangeCheck usedRangeCheck(len);

	// Check headers:
	size_t headerCount = 0;
	const SndHeader *header = (const SndHeader *)unscrambledBody;
	for (; ; ++header, ++headerCount)
	{
		if (headerCount*sizeof(SndHeader) >= bDataSection)
			break;

		// Mark header bytes as used:
		const uint32_t bHeader = headerCount*sizeof(SndHeader);
		const uint32_t eHeader = bHeader + sizeof(SndHeader);
		usedRangeCheck.markAsUsed(bHeader, eHeader);

		// Check for empty header (each header probably corresponds to a
		// resource index, but not all of the indexes point to actual data):
		if (header->len == 0x00000000 && header->addr == 0x00000000)
			continue;

		if (header->len == 0xFFFFFFFF && header->addr == 0xFFFFFFFF)
			continue;

		// Check if len and addr are valid:
		const uint32_t bBody = addr + sizeof(BlockHeadTail);
		ptrdiff_t bRes = header->addr - bBody;
		ptrdiff_t eRes = bRes + header->len;

		if (bRes < 0 || bRes >= ptrdiff_t(len) ||
			eRes < 0 || eRes > ptrdiff_t(len))
		{
			throw std::runtime_error("Resource boundaries exceed data.");
		}

		// Save resource to file:
		std::string fnOut = Path::join(path, format("%02d.snd%02d.%s", blkCount, headerCount, estimateSndTypeExt(&unscrambledBody[bRes], eRes-bRes)));
		FILE *fh = fopen(fnOut.c_str(), "wb");
		if (!fh)
		{
			throw std::runtime_error("Couldn't open output file for writing.");
		}
		else
		{
			fwrite(&unscrambledBody[bRes], 1, eRes-bRes, fh);
			fclose(fh);
		}

		// Mark resource bytes as used:
		usedRangeCheck.markAsUsed(bRes, eRes);
	}

	// Check if unused bytes are data:
	for (int i = 0; i < usedRangeCheck.size(); ++i)
	{
		bool unusedRangeContainsData = false;
		for (size_t k = usedRangeCheck[i].b; k < usedRangeCheck[i].e; ++k)
		{
			if (unscrambledBody[k] != 0xFF && unscrambledBody[k] != 0x00)
			{
				unusedRangeContainsData = true;
				break;
			}
		}

		if (unusedRangeContainsData)
			printf("Warning: Unused data range 0x%08X-0x%08X contains data other than 0x00 and 0xFF.\n", usedRangeCheck[i].b, usedRangeCheck[i].e);
	}
}

// ---------------------------------------------------------------------------------------
// "0x0106" BLOCK
// ---------------------------------------------------------------------------------------

#pragma pack(push) // remember struct alignment
#pragma pack(1) // set struct alignment to 1 byte
struct Blk0106Header
{
	uint32_t len;
	uint32_t addr;
};
#pragma pack(pop) // restore struct alignment

inline void parse0106Block(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	// NOTE:
	// In all firmwares that have a 0x0106 block, there is always just one header.
	// All data bytes are in range [0x00;0x40[ (6 bit data).
	// The 0x0106 is same (except for address) for E-P1, E-P2 and E-PL1; for E-30 the data is slightly different (but similar).


	// Blocks have a fixed length sub-block with headers only, some padding, data, some more padding:
	uint32_t bDataSection;
	if (flags == FLAGS_0106)
		bDataSection = 0x000003E0;
	else
		throw std::runtime_error("Unknown flags for image block, can't parse.");

	if (len < bDataSection)
		throw std::runtime_error("Block length too small to have valid header sub-block.");

	// For debugging, mark which bytes have been used from the block:
	UsedByteRangeCheck usedRangeCheck(len);

	// Check headers:
	size_t headerCount = 0;
	const Blk0106Header *header = (const Blk0106Header *)unscrambledBody;
	for (; ; ++header, ++headerCount)
	{
		if (headerCount*sizeof(Blk0106Header) >= bDataSection)
			break;

		// Mark header bytes as used:
		const uint32_t bHeader = headerCount*sizeof(Blk0106Header);
		const uint32_t eHeader = bHeader + sizeof(Blk0106Header);
		usedRangeCheck.markAsUsed(bHeader, eHeader);

		// Check for empty header (each header probably corresponds to a
		// resource index, but not all of the indexes point to actual data):
		if (header->len == 0x00000000 && header->addr == 0x00000000)
			continue;

		if (header->len == 0xFFFFFFFF && header->addr == 0xFFFFFFFF)
			continue;

		// Check if len and addr are valid:
		const uint32_t bBody = addr + sizeof(BlockHeadTail);
		ptrdiff_t bRes = header->addr - bBody;
		ptrdiff_t eRes = bRes + header->len;

		if (bRes < 0 || bRes >= ptrdiff_t(len) ||
			eRes < 0 || eRes > ptrdiff_t(len))
		{
			throw std::runtime_error("Resource boundaries exceed data.");
		}

		// Save resource to file:
		std::string fnOut = Path::join(path, format("%02d.b106%02d.%s", blkCount, headerCount, "unknown.bin"));
		FILE *fh = fopen(fnOut.c_str(), "wb");
		if (!fh)
		{
			throw std::runtime_error("Couldn't open output file for writing.");
		}
		else
		{
			fwrite(&unscrambledBody[bRes], 1, eRes-bRes, fh);
			fclose(fh);
		}

		// Mark resource bytes as used:
		usedRangeCheck.markAsUsed(bRes, eRes);
	}

	// Check if unused bytes are data:
	for (int i = 0; i < usedRangeCheck.size(); ++i)
	{
		bool unusedRangeContainsData = false;
		for (size_t k = usedRangeCheck[i].b; k < usedRangeCheck[i].e; ++k)
		{
			if (unscrambledBody[k] != 0xFF && unscrambledBody[k] != 0x00)
			{
				unusedRangeContainsData = true;
				break;
			}
		}

		if (unusedRangeContainsData)
			printf("Warning: Unused data range 0x%08X-0x%08X contains data other than 0x00 and 0xFF.\n", usedRangeCheck[i].b, usedRangeCheck[i].e);
	}
}

// ---------------------------------------------------------------------------------------
// Switch
// ---------------------------------------------------------------------------------------

inline void parseBlockBody(const byte *unscrambledBody, size_t len, uint16_t flags, uint32_t addr, std::string path, size_t blkCount)
{
	switch (flags)
	{
		case FLAGS_CODE1:
		case FLAGS_CODE2:
			parseCodeBlock(unscrambledBody, len, flags, addr, path, blkCount);
			break;
		case FLAGS_LANG:
			parseLangBlock(unscrambledBody, len, flags, addr, path, blkCount);
			break;
		case FLAGS_IMGS1:
		case FLAGS_IMGS2:
			parseImgBlock(unscrambledBody, len, flags, addr, path, blkCount);
			break;
		case FLAGS_SNDS:
			parseSndBlock(unscrambledBody, len, flags, addr, path, blkCount);
			break;
		case FLAGS_0106:
			parse0106Block(unscrambledBody, len, flags, addr, path, blkCount);
			break;
		default:
			break; // can't parse unknown block
	}
}

#endif