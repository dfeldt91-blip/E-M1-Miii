----------------------------------------------------------------------------------------------------
Olympus E-Series Firmware Tools
----------------------------------------------------------------------------------------------------

A toolset for working with Olympus camera firmwares.

Tools:
	-	oly_fw_manip.exe		Tool for manipulating firmware binaries.
	-	oly_fw_server_emu.py	A tool for emulating the Olympus firmware update servers, to allow 
								flashing camera with custom firmwares (as well as arbitrary 
								upgrades/downgrades).
								See top of .py file for instructions.

Data files:
	-	oly_fw_linklist-12_07_2010.html		HTML page with links to all (?) Olympus firmware binaries 
											thus far.
	-	oly_model_body.xml					XML file with model id/name table (bodies).
	-	oly_model_lens.xml					XML file with model id/name table (lenses).
								
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!! CAUTION:	These tools may be able to "brick" (irreversibly damage) your camera relatively easily.
!!			Use with care.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

----------------------------------------------------------------------------------------------------
- oly_fw_manip.exe
----------------------------------------------------------------------------------------------------

This is a simple tool to manipulate Olympus E-series firmware files.
The tool offers the following functions:
	1)	Unpack firmware files.
	2)	Pack firmware files.
	3)	Extract resources.
	4)	Estimate loading address.

1	-	Unpack firmware files.
Using option --unpack or --unpack-s.
Olympus firmware files (.BIN) are structured in blocks of different kinds of data (e.g. code, images, 
sounds, language files, etc.). Furthermore the data is "scrambled" (a simple type of obfuscation).
This option breaks down the file into its different blocks and unscrambles the data. A description of the 
file's original structure is stored in XML format. This output XML file can be used for further operations 
(e.g. re-packing the firmware into a BIN file).
The --unpack option is used for regular firmwares downloaded from the web. The --unpack-s option is for 
special "S files" that are part of service/repair card update packages and follow a different format.
Note that unpacking an "S file" does not produce an XML file and cannot be reversed with the current tool.
There's a special mode for --unpack when the --out flag is left empty; in that case it will unpack the 
binary in memory only without writing any output files. This is useful if other tools want to validate 
a firmware binary. In this mode the last line of the stdout console output will contain parsable information
with format "VALIDATE OK|ERROR (HARDWARE_KIND) (MODEL_ID) (VERSION)", e.g. "VALIDATE ERROR" or "VALIDATE OK E 0680 1402".

2	-	Packing firmware files.
Using option --pack.
The unpacked firmware files can be re-packed into a BIN file.

3	-	Extracting resources.
Using option --extract-resources.
Certain types of resources can be extracted from the data blocks of an unpacked firmware. For instance 
images (.jpg, .ico, etc.) and a sounds (.wav) can be extracted. However, not all of the data blocks can 
be fully parsed (some of the structures are not known). Also, there is currently no way to re-assemble a 
data block from its extracted resources (so it is impossible to replaced some image for instance).

4	-	Estimating loading address.
Using option --analyze.
Using some simple statistical analysis and ASCII debug strings in the code data, we can make a guess of 
the code's loading address (used for disassembly). There's no guarantee that this will be always 
successful.

----------------------------------------------------------------------------------------------------
File structure:
----------------------------------------------------------------------------------------------------

Regular BIN files are structures as:
<block><block>...<block>
<block> = <head><body><tail>

S-files are structured as:
Single block with <body><stail>

<head> and <tail> have structure:
Offset (hex):	Size:	Description:
00 (00)			2		Block type (1).
02 (02)			2		Model type (2).
04 (04)			4		Zero padding / unknown (3).
08 (08)			4		Loading address (4).
12 (0C)			4		Size of body.
16 (10)			2		Version (5).
18 (12)			2		Zero padding.
20 (14)			2		Block flags (6).
22 (16)			6		Zero padding.
28 (1C)			4		Checksum (7).
32 (20) = Total size.

(1) Block type :	Seems to be a kind of "macro" block type, mainly determining in which ROM the block 
					should be stored (e.g. main microprocessor ROM, or SWD/IS ROM).
(2) Model type :	Code identifying camera/lens/etc. There's no direct relation between numbers used in 
					product names (e.g. E-510) and code used (e.g. 0x0410). Note that model types are not 
					globally unique, but depend on block type (e.g. one model type may refer to both a lens 
					and a camera body depending on block type field).
(3) Unknown :		Normally zero, for some lens firmwares this field can have values of 0, 1, or 2. Some 
					lens firmwares contain e.g. two very similar blocks with different versions, and different 
					values for this field.
(4)	Load addr. :	Address of the block (incl. head) in the ROM. For some newer firmwares, e.g. E-P1, E-P2, 
					E-PL, loading address of main code block does not seem to correspond to actual loading 
					address of code.
(5) Version :		Within one BIN file different blocks can have different versions, the main code block 
					usually has same version mentioned in BIN filename.
					Specified as a binary encoded decimal, e.g. 0x1102 for v1.1.0.2.
(6) Flags :			Flags determine the type of data in the block (e.g. code, images, sounds, etc.), and 
					whether it is scrambled or not.
(7) Checksum :		For <head> checksum is zero, for <tail> it is the actual checksum.

<stail> has structure:
Offset (hex):	Size:	Description:
00 (00)			2		Block type.
02 (02)			2		Model type.
04 (04)			12		Zero padding (8).
16 (10)			4		Checksum.
20 (14)			4		Loading address.
24 (18)			4		Id "BOOT".
28 (1C)			2		Version.
30 (1E)			2		Zero padding.
32 (20) = Total size.

(8) Zero padding :	It is quite possible that 4 bytes of these 12 bytes are actually a "flags" field, however as 
					for S files the flags field is actually 0x0000 (unscrambled code), there's no way of telling.

Some of the data blocks (e.g. image data block) contain multiple resources (e.g. multiple jpg and bmp files) within 
one block. The general structure is something like:
<res_head><res_head>..<res_head><res_data><res_data>..<res_data>
The offset where headers end and data starts seems to be fixed and determined by the flags field (not directly, 
but e.g. when flags = 0x0102, data starts at 0xBE0; when flags = 0x0104, data starts at 0x3E0).
There can be invalid resource headers (e.g. all 0x00 or 0xFF) in between valid headers (resources probably accessed 
by index).

Block types:
"OE"		Main microprocessor ROM block.
"OM"		SWD/IS microprocessor ROM block (?).
"OA"		Additional language block.
"OL"		Lens firmware block.
?			Flash/strobe firmware block.

Flags:
0x0000		Code, unscrambled (perhaps the 0x0100 bit determines scrambling, but only code is scrambled).
0x0100		Code, scrambled.
0x0101		Multiple language block, text strings, maybe fonts, etc.
0x0102		Images.
0x0103		Sounds (used in some mju cameras).
0x0104		Images (used in some mju cameras for photo text overlays).
0x0105		Code (used in some mju cameras).
0x0106		Unknown content (all bytes in range [0x00;0x40[, used in E-30, E-P1, E-P2, E-PL1)
		
----------------------------------------------------------------------------------------------------
Contributors:
----------------------------------------------------------------------------------------------------

Probably incomplete list:
-	mx3 (work on FE-series, decryption in C, meaning of block flags, meaning of model signatures)
-	Altsoph (work on E-series, decryption in PHP, checksum)
-	wictor (meaning of block type signatures, regional variants E-3 firmwares)
-	Virus (identifying CPU, disassembling using IDA, successfully uploading modified firmware)
-	tester13 (loading address analysis idea)
-	foxo (E-3 card firmwares)


